export class StackDto {
    minPrice: number;
    currentPrice: number;
    username: string;
}