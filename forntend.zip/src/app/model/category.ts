export class Category {
    name: string;
}