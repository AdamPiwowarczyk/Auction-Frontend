export enum SubjectsFilter {
    Active = 'Aktywne',
    New = 'Nowe',
    Bidded = 'Licytowane',
    Bought = 'Kupione',
    Archive = 'Archiwalne'
}