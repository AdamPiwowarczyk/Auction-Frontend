export class UserInfo {
    username: string;
    roles: String[];
}